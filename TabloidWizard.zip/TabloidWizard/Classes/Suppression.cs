﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tabloid
{
    public static class Suppression
    {
        public enum mode { Oui, Non, Auto };
    }
}
