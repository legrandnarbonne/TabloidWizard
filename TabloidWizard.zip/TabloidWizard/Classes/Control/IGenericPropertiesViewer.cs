﻿namespace TabloidWizard.Classes.Control
{
    internal interface IGenericPropertiesViewer
    {

        string TypesName { get; set; }
    }
}